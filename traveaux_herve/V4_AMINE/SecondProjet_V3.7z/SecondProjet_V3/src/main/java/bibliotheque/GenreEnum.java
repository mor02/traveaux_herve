package bibliotheque;

public enum GenreEnum {

    HISTORIQUE, 
    POLICIER, 
    ROMAN, 
    DOCUMENTAIRE;
}
