package bibliotheque;

public interface HasCout {
    
    int getCout();
    
    void setCout(int cout);
    
}
