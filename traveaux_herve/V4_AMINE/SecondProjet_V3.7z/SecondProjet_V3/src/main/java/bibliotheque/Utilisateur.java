package bibliotheque;

import java.util.List;

public class Utilisateur implements UtilisateurDefinition {

    public Utilisateur(String login, String password) {
        
    }
    
    public String getLogin() {
        return null;
    }

    public boolean checkPassword(String password) {
        return false;
    }

    public void emprunter(Empruntable empruntable) {
    }

    public void rendre(Empruntable empruntable) {
    }

    public List<Empruntable> getDocumentsEmpruntes() {
        return null;
    }
    
}
